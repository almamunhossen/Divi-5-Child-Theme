
<?php
/**
 * AmhajDivi Child Theme — functions.php
 *
 * @package AmhajDivi
 * @author  Al Mamun Hossen
 * @link    https://almamunhossen.com
 * @license GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

/**
 * Child theme constants.
 */
define( 'AMHAJDIVI_VERSION', '1.0.0' );
define( 'AMHAJDIVI_DIR', get_stylesheet_directory() );
define( 'AMHAJDIVI_URI', get_stylesheet_directory_uri() );

/**
 * Enqueue child theme stylesheets.
 */
function amhajdivi_enqueue_styles() {

    $child_css = AMHAJDIVI_DIR . '/style.css';

    if ( is_readable( $child_css ) ) {
        wp_enqueue_style(
            'amhajdivi-child-style',
            get_stylesheet_uri(),
            array( 'divi-style-parent' ),
            (string) filemtime( $child_css )
        );
    }

    $custom_css = AMHAJDIVI_DIR . '/assets/css/custom.css';

    if ( is_readable( $custom_css ) ) {
        wp_enqueue_style(
            'amhajdivi-custom-style',
            AMHAJDIVI_URI . '/assets/css/custom.css',
            array( 'amhajdivi-child-style' ),
            (string) filemtime( $custom_css )
        );
    }
}
add_action( 'wp_enqueue_scripts', 'amhajdivi_enqueue_styles', 20 );

/**
 * Enqueue child theme JavaScript.
 */
function amhajdivi_enqueue_scripts() {

    $custom_js = AMHAJDIVI_DIR . '/assets/js/custom.js';

    if ( is_readable( $custom_js ) ) {
        wp_enqueue_script(
            'amhajdivi-custom-script',
            AMHAJDIVI_URI . '/assets/js/custom.js',
            array( 'jquery' ),
            (string) filemtime( $custom_js ),
            true
        );
    }
}
add_action( 'wp_enqueue_scripts', 'amhajdivi_enqueue_scripts', 20 );

/**
 * Load child theme translations.
 */
function amhajdivi_setup() {

    load_child_theme_textdomain(
        'amhajdivi',
        AMHAJDIVI_DIR . '/languages'
    );
}
add_action( 'after_setup_theme', 'amhajdivi_setup' );




// Add your custom PHP functions below this line.
